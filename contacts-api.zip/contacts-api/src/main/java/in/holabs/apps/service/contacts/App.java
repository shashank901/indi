package in.holabs.apps.service.contacts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Hello world!
 *
 */
@SpringBootApplication
@EnableConfigurationProperties
@EntityScan(basePackages = {"in.holabs.apps"})
public class App 
{
    public static void main( String[] args )
    {
        SpringApplication.run( App.class,args );
    }
}
