package in.holabs.apps.service.contacts.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import in.holabs.apps.service.contacts.model.Contact;
import in.holabs.apps.service.contacts.repository.ContactRepository;

/**
 * 
 * 1- Create 2- Read
 * 
 * @author ssingh11
 *
 */
@RestController
@RequestMapping("api/v1/")
public class ContactContoller {
	@Autowired
	ContactRepository contactRepository;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String home() {
		return "Contact App home";
	}

	@RequestMapping(value = "contact", method = RequestMethod.GET)
	public List<Contact> list() {
		return contactRepository.findAll();

	}

	@RequestMapping(value = "contact/{id}", method = RequestMethod.GET)
	public Contact get(@PathVariable Long id) {

		return contactRepository.findOne(id);

	}

	@RequestMapping(value = "contact", method = RequestMethod.POST)
	public @ResponseBody Contact create(@RequestBody Contact contact) {

		return contactRepository.saveAndFlush(contact);

	}

	@RequestMapping(value = "contact/{id}", method = RequestMethod.PUT)
	public @ResponseBody Contact update(@PathVariable Long id, @RequestBody Contact contact) {
		Contact contactExisting = contactRepository.findOne(id);
		BeanUtils.copyProperties(contact, contactExisting);
		
		return contactRepository.saveAndFlush(contactExisting);

	}

	@RequestMapping(value = "contact/{id}", method = RequestMethod.DELETE)
	public @ResponseBody Contact delete(@PathVariable Long id) {
		Contact contactExisting = contactRepository.findOne(id);
		contactRepository.delete(contactExisting);
		return contactExisting;

	}

}
