package in.holabs.apps.service.contacts.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import in.holabs.apps.service.contacts.model.Contact;


public class ContactStub {
	private static Map<Long, Contact> contacts = new HashMap<Long, Contact>();
	private static Long idIndex = 3L;
	
	static{
		Contact a = new Contact(1L, "Shashank", "Bangalore", "Engineer and Trainer", "","","","");
		contacts.put(1L, a);
		Contact b = new Contact(2L, "Sanjay", "Bangalore", "Manager Engineerr", "","","","");
		contacts.put(2L, b);
		Contact c = new Contact(3L, "Rahul", "Nagpur", "Engineer and Trainer", "","","","");
		contacts.put(3L, c);
		
	}
	public static List<Contact> list() {
		return new ArrayList<Contact>(contacts.values());
	}
	
	public static Contact create(Contact contact) {
		idIndex += idIndex;
		contact.setId(idIndex);
		((Map<Long, Contact>) contacts).put(idIndex, contact);
		return contact;
	}
	
	public static Contact get(Long id) {
		return contacts.get(id);
	}

	public static Contact update(Long id, Contact contact) {
		((Map<Long, Contact>) contacts).put(id, contact);
		return contact;
	}

	public static Contact delete(Long id) {
		return contacts.remove(id);
	}

}
