package in.holabs.apps.service.contacts.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * TODO://Implement as per SOLID principle import\export as json, text & xml
 * 
 * @author ssingh11
 *
 */
@Entity
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;
	String name;
	String lastname;
	String middlename;
	String phonenum;
	String address;
	String notes;
	String rawdata;

	public Contact() {
	}

	public Contact(Long id, String name, String lastname, String middlename, String address, String notes,
			String phonenum, String rawdata) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.notes = notes;
		this.phonenum = phonenum;
		this.lastname = lastname;
		this.middlename = middlename;
		this.rawdata = rawdata;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getPhonenum() {
		return phonenum;
	}

	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getRawdata() {
		return rawdata;
	}

	public void setRawdata(String rawdata) {
		this.rawdata = rawdata;
	}


	
	
}
