package in.holabs.apps.service.contacts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.holabs.apps.service.contacts.model.Contact;

public interface ContactRepository extends JpaRepository<Contact, Long> {

}
