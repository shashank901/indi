package in.holabs.apps.service.contacts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.holabs.apps.service.contacts.model.Shipwreck;

public interface ShipwreckRepository extends JpaRepository<Shipwreck, Long> {

}
